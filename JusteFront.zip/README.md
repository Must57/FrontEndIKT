# FrontEndIKT

Le FrontEnd d'I Know Travel. 

La page gérant les préférences sera améliorées. 
State Management sera aussi implementée.


#V1.0

La première version comporte seulement les pages nécessaires pour débuter.

